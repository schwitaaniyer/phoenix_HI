# data_fetcher.py
from django.conf import settings
from django.utils import timezone
from ..models import RFParameters, PacketLoss
import requests
import logging
from datetime import timedelta
import json

logger = logging.getLogger(__name__)

class ZabbixDataFetcher:
    def __init__(self):
        self.api_url = settings.ZABBIX_API_URL
        self.auth_token = settings.ZABBIX_AUTH_TOKEN
        self.interval = settings.ZABBIX_FETCH_INTERVAL
        logger.info(f"Initialized ZabbixDataFetcher with URL: {self.api_url}")

    def fetch_zabbix_data(self):
        """Fetch data from Zabbix API"""
        payload = {
            "jsonrpc": "2.0",
            "method": "item.get",
            "params": {
                "output": ["itemid", "name", "lastvalue", "lastclock"],
                "host": "TESTSITE1",
                "filter": {
                    "name": [
                        "Interface LTE_Inbuilt1(): LTE modem RSRP",
                        "Interface LTE_Inbuilt1(): LTE modem RSRQ",
                        "Interface LTE_Inbuilt1(): LTE modem SINR",
                        "LTE_Inbuilt1LTE modem RSSI",
                        "PacketLoss:[SNMPPingLatencyResultSIM1.6]",
                        "Interface LTE_Inbuilt2(): LTE modem RSRP",
                        "Interface LTE_Inbuilt2(): LTE modem RSRQ",
                        "Interface LTE_Inbuilt2(): LTE modem SINR",
                        "LTE_Inbuilt2LTE modem RSSI",
                        "PacketLoss:[SNMPPingLatencyResultSIM2.7]"
                    ]
                }
            },
            "auth": self.auth_token,
            "id": 1
        }

        try:
            response = requests.post(self.api_url, json=payload, timeout=10)
            response.raise_for_status()
            data = response.json()
            return data.get("result", [])
        except requests.exceptions.RequestException as e:
            logger.error(f"Error fetching Zabbix data: {e}")
            return []
        except json.JSONDecodeError as e:
            logger.error(f"Error parsing JSON response: {e}")
            return []

    def process_and_save_data(self, data):
        """Process and save data to Django models"""
        if not data:
            logger.info("No data received to process")
            return

        lte1_params = {}
        lte2_params = {}

        for item in data:
            # Convert timestamp to aware datetime
            naive_timestamp = timezone.datetime.fromtimestamp(int(item["lastclock"]))
            aware_timestamp = timezone.make_aware(
                naive_timestamp, 
                timezone=timezone.get_current_timezone()
            )
            
            # Add IST offset
            aware_timestamp = aware_timestamp + timedelta(hours=5, minutes=30)

            try:
                if "LTE_Inbuilt1" in item["name"] or "SIM1" in item["name"]:
                    if self._is_new_data("LTE1", aware_timestamp):
                        self._process_lte_item(item, lte1_params, aware_timestamp, "LTE1")
                elif "LTE_Inbuilt2" in item["name"] or "SIM2" in item["name"]:
                    if self._is_new_data("LTE2", aware_timestamp):
                        self._process_lte_item(item, lte2_params, aware_timestamp, "LTE2")
            except Exception as e:
                logger.error(f"Error processing item {item['name']}: {e}")

        # Save the collected data
        self._save_parameters(lte1_params, "LTE1")
        self._save_parameters(lte2_params, "LTE2")

    def _is_new_data(self, lte_type, timestamp):
        """Check if the data is new for the given LTE type and timestamp."""
        return not RFParameters.objects.filter(
            lte_type=lte_type,
            timestamp=timestamp
        ).exists()

    def _process_lte_item(self, item, params_dict, timestamp, lte_type):
        """Helper method to process individual LTE items"""
        value = float(item["lastvalue"])
        params_dict["timestamp"] = timestamp

        if "RSRP" in item["name"]:
            params_dict["rsrp"] = value
        elif "RSRQ" in item["name"]:
            params_dict["rsrq"] = value
        elif "RSSI" in item["name"]:
            params_dict["rssi"] = value
        elif "SINR" in item["name"]:
            params_dict["sinr"] = value
        elif "PacketLoss" in item["name"]:
            PacketLoss.objects.create(
                timestamp=timestamp,
                lte_type=lte_type,
                packet_loss=value
            )

    def _save_parameters(self, params, lte_type):
        """Helper method to save RF parameters"""
        required_keys = ["timestamp", "rsrp", "rsrq", "rssi", "sinr"]
        if all(key in params for key in required_keys):
            RFParameters.objects.create(
                timestamp=params["timestamp"],
                lte_type=lte_type,
                rsrp=params["rsrp"],
                rsrq=params["rsrq"],
                rssi=params["rssi"],
                sinr=params["sinr"],
            )

# tasks.py
