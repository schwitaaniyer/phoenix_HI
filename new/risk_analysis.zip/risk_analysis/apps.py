from django.apps import AppConfig


class RiskAnalysisConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'risk_analysis'
